Video Link for Thyroid Disorders
https://drive.google.com/file/d/1ivlWwYNOFwK7koly79ppumXvXUd1-DHN/view?usp=sharing
